# Notatka w Markdown

Link do [planu ogrodu](../Ogr%C3%B3d%20planbud%C5%BCet.html) i **pogrubienie**.

- [ ] zadanie w Markdown
- [x] zrobione
