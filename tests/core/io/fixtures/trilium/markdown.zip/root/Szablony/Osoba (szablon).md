# Osoba (szablon)
Szablon notatki o osobie.