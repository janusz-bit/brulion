# Zarchiwizowana notatka
Ukryta w drzewie przez #archived, ale eksportowana.