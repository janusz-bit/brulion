# Jan Kowalski
Fikcyjna osoba do testów.