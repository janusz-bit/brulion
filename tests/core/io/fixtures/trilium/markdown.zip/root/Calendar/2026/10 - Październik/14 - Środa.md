# 14 - Środa
Spotkanie w sprawie działki: <a class="reference-link" href="../../../Projekty/Spotkanie%202026-10-14.md">Spotkanie 2026-10-14</a>.

- [x] Zadzwonić do sąsiada