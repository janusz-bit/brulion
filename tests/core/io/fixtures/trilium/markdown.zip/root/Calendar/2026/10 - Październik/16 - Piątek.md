# 16 - Piątek
Dziś: **sadzenie czosnku**.

- [ ] Posadzić czosnek o 10:00
- [/] Grabienie liści

Zobacz <a class="reference-link" href="../../../Projekty/Zadania.md">Zadania</a>.