# 31 - Środa
Podsumowanie roku. Sylwester 🎆