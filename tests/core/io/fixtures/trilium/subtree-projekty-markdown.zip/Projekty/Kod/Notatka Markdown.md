# Notatka w Markdown

Link do [planu ogrodu](../Ogr%C3%B3d%20planbud%C5%BCet.md) i **pogrubienie**.

- [ ] zadanie w Markdown
- [x] zrobione
