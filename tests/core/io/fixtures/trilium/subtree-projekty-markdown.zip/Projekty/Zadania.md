# Zadania
- [x] Kupić nasiona marchwi
- [ ] Przekopać grządkę (ok. 2 h)
- [/] Zamówić **kompostownik**
- [?] Szklarnia?
- [-] Oczko wodne
    - [ ] zagnieżdżone: wybrać folię