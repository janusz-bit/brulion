const grządki = ["marchew"];
