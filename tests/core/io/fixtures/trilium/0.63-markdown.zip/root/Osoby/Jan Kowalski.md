# Jan Kowalski
Fikcyjna osoba.