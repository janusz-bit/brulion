# Zadania
*   Kupić nasiona marchwi
*   Przekopać grządkę