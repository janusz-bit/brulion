# Bardzo długi tytuł notatki o planowaniu ogrodu warzywnego na sezon 2026 i dalej
Ta wersja obcina nazwy plików z danymi do 30 znaków.