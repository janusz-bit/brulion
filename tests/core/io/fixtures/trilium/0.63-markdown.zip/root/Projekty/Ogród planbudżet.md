# Ogród: plan/budżet?
Tekst **pogrubiony**, _kursywa_, podkreślenie, ~przekreślenie~, `kod()`, H2O, zaznaczenie, czerwony 🌱.

Znaki: <b>, \*gwiazdki\*, \_podkreślniki\_, \[nawiasy\], a&b.

Nagłówek 2
----------

### Nagłówek 3

*   Warzywa
    *   marchew
*   Kwiaty

1.  Pierwszy
2.  Drugi

*   Zrobione
*   Do zrobienia

| Roślina | Koszt |
| --- | --- |
| Pomidory | 12,50 zł |

```text-x-python
def f():
    return "żółw"
```

> Cytat ąę.

Wzór \\(E=mc^2\\).

* * *

Linki: [Spotkanie 2026-10-14](Spotkanie%202026-10-14.md), [autor](../Osoby/Jan%20Kowalski.md), [Kod](Kod), [Zadania](1_Zadania.md), [Sekretne hasła](../Archiwum/undefined), [16 - Friday](../Calendar/2026/10%20-%20October/16%20-%20Friday.md), [Bardzo długi tytuł](Bardzo%20d%C5%82ugi%20tytu%C5%82%20notatki%20o%20p.md), [example.org](https://example.org/), załącznik [lista zakupów.txt](Ogród planbudżet_lista zakupów.txt).

![](Ogród planbudżet_zdjęcie grząd.png)

![](kropka.png)