# 16 - Friday
Dziś: **sadzenie czosnku**.

*   Posadzić czosnek