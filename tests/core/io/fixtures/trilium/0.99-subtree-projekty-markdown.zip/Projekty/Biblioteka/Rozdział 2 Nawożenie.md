# Rozdział 2: Nawożenie
Kompost > nawozy sztuczne & inne.