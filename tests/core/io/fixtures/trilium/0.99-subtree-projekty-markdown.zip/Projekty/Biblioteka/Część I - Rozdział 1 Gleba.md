# Rozdział 1: Gleba
Gleba powinna być _przepuszczalna_.