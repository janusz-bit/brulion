// Licznik grządek
const grządki = ["marchew", "pietruszka"];
api.log(`Liczba: ${grządki.length}`);
